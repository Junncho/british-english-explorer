import { useMemo, useState } from 'react';
import { finalTest, pairQ, pool, practice, pron, readings, spelling, spellQ, spellRules, vocab, type Progress, type Q } from './data';
import { Btn, Card, PageTitle, QuestionCard, Tabs, Test, speak } from './ui';

type P = { p: Progress; set: (f: (p: Progress) => Progress) => void };
const shuffle = <T,>(a: T[]) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };

// ---------------- Vocabulary ----------------
function Flashcards({ p, set }: P) {
  const [i, setI] = useState(0); const [flip, setFlip] = useState(false); const [front, setFront] = useState<'us' | 'uk'>('us');
  const [uk, us] = vocab[i]; const known = p.known.includes(uk);
  const go = (d: number) => { setI((i + d + vocab.length) % vocab.length); setFlip(false); };
  const mark = (k: boolean) => { set((x) => ({ ...x, known: k ? Array.from(new Set([...x.known, uk])) : x.known.filter((w) => w !== uk) })); go(1); };
  const shown = flip ? (front === 'us' ? 'uk' : 'us') : front;
  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-3 flex items-center justify-between text-sm text-slate-600">
        <span>Card {i + 1} of {vocab.length} · Known: {p.known.length}/{vocab.length}</span>
        <Btn v="ghost" onClick={() => { setFront(front === 'us' ? 'uk' : 'us'); setFlip(false); }}>Front: {front === 'us' ? 'American' : 'British'}</Btn>
      </div>
      <button onClick={() => setFlip(!flip)} aria-label="Flip card"
        className={`flex h-56 w-full flex-col items-center justify-center rounded-lg border-4 p-4 text-center shadow-md ${shown === 'uk' ? 'border-flag bg-white' : 'border-navy bg-navy text-white'}`}>
        <span className="mb-2 text-sm opacity-80">{shown === 'uk' ? '🇬🇧 British English' : '🇺🇸 American English'}</span>
        <span className={`font-serif text-4xl font-bold ${shown === 'uk' ? 'text-navy' : ''}`}>{shown === 'uk' ? uk : us}</span>
        <span className="mt-3 text-xs opacity-70">{flip ? '' : 'Tap to reveal the other word'}</span>
      </button>
      <div className="mt-3 flex flex-wrap justify-center gap-2">
        <Btn v="ghost" onClick={() => go(-1)}>Previous</Btn>
        <Btn v="ghost" onClick={() => speak(uk, 'en-GB')}>🔊 UK word</Btn>
        <Btn v="ghost" onClick={() => go(1)}>Next</Btn>
      </div>
      <div className="mt-3 flex justify-center gap-2">
        <Btn v="red" onClick={() => mark(false)}>Still learning</Btn>
        <Btn onClick={() => mark(true)}>I know it {known && '✓'}</Btn>
      </div>
    </div>
  );
}
function VocabQuiz({ p, set }: P) {
  const [run, setRun] = useState(0);
  const qs = useMemo<Q[]>(() => shuffle(pool.map((_, i) => i)).slice(0, 10).map((i) => pairQ(i, Math.random() < 0.5 ? 'us2uk' : 'uk2us')), [run]);
  return (<div><p className="mb-3 text-sm text-slate-600">10 random questions. Best score: {p.vocabBest}/10</p>
    <Test key={run} questions={qs} onRestart={() => setRun(run + 1)} onFinish={(s) => set((x) => ({ ...x, vocabBest: Math.max(x.vocabBest, s) }))} /></div>);
}
function VocabList() {
  const [f, setF] = useState('');
  return (<div><input value={f} onChange={(e) => setF(e.target.value)} placeholder="Search words…" className="mb-3 w-full rounded-md border border-slate-300 px-3 py-2" />
    <Card className="overflow-x-auto p-0"><table className="w-full text-left text-sm"><thead className="bg-navy text-white"><tr><th className="p-3">🇬🇧 British</th><th className="p-3">🇺🇸 American</th></tr></thead>
      <tbody>{vocab.filter(([a, b]) => (a + b).toLowerCase().includes(f.toLowerCase())).map(([a, b]) => <tr key={a} className="border-t even:bg-slate-50"><td className="p-3 font-semibold text-navy">{a}</td><td className="p-3">{b}</td></tr>)}</tbody></table></Card></div>);
}
export function Vocabulary(props: P) {
  const [t, setT] = useState('Flashcards');
  return (<div><PageTitle title="Vocabulary" sub="50 British and American word pairs." />
    <Tabs tabs={['Flashcards', 'Multiple choice', 'Word list']} value={t} onChange={setT} />
    {t === 'Flashcards' ? <Flashcards {...props} /> : t === 'Multiple choice' ? <VocabQuiz {...props} /> : <VocabList />}</div>);
}

// ---------------- Spelling ----------------
function SpellPractice({ p, set }: P) {
  const [order, setOrder] = useState(() => shuffle(spelling.map((_, i) => i)));
  const [k, setK] = useState(0);
  const [uk, us, rule] = spelling[order[k % order.length]];
  const q: Q = { q: `American spelling: "${us}". Type the British spelling.`, answer: uk, explain: `Rule: ${rule}.` };
  return (<div className="mx-auto max-w-xl"><p className="mb-3 text-sm text-slate-600">Spelt correctly so far: {p.spelled.length}/{spelling.length}</p>
    <QuestionCard key={k} q={q} n={k + 1} onResult={(ok) => ok && set((x) => ({ ...x, spelled: Array.from(new Set([...x.spelled, uk])) }))} />
    <div className="mt-3 flex justify-end gap-2"><Btn v="ghost" onClick={() => { setOrder(shuffle(order)); setK(0); }}>Shuffle</Btn><Btn onClick={() => setK(k + 1)}>Next word</Btn></div></div>);
}
export function Spelling(props: P) {
  const [t, setT] = useState('Rules');
  return (<div><PageTitle title="Spelling" sub="Common UK and US spelling differences." />
    <Tabs tabs={['Rules', 'Type the spelling', 'Choose the spelling']} value={t} onChange={setT} />
    {t === 'Rules' && <div className="grid gap-4 md:grid-cols-2">{spellRules.map((r) => (
      <Card key={r}><h3 className="mb-2 text-lg font-bold">{r}</h3>
        {r === 'ise / ize' && <p className="mb-2 text-xs text-slate-500">Both -ise and -ize are used in Britain (Oxford spelling uses -ize), but -ise is the most common.</p>}
        {r === 'ce / se' && <p className="mb-2 text-xs text-slate-500">In British English, licence is the noun and license is the verb.</p>}
        <ul className="space-y-1 text-sm">{spelling.filter((s) => s[2] === r).map(([a, b]) => <li key={a}><span className="font-semibold text-navy">🇬🇧 {a}</span> <span className="text-slate-500">vs</span> 🇺🇸 {b}</li>)}</ul></Card>))}</div>}
    {t === 'Type the spelling' && <SpellPractice {...props} />}
    {t === 'Choose the spelling' && <ChooseSpelling />}</div>);
}
function ChooseSpelling() {
  const [qs] = useState(() => shuffle(spelling.map((_, i) => i)).slice(0, 8).map((i, k) => spellQ(i, k)));
  return <div className="space-y-3">{qs.map((q, i) => <QuestionCard key={i} q={q} n={i + 1} />)}</div>;
}

// ---------------- Pronunciation ----------------
export function Pronunciation({ p, set }: P) {
  const toggle = (id: string) => set((x) => ({ ...x, pron: x.pron.includes(id) ? x.pron.filter((s) => s !== id) : [...x.pron, id] }));
  return (<div><PageTitle title="Pronunciation" sub="T and R sounds, intonation and rhythm." />
    <div className="space-y-5">{pron.map((s) => (
      <Card key={s.id}>
        <div className="flex items-start justify-between gap-3"><h2 className="text-2xl font-bold">{s.title}</h2>
          <Btn v={p.pron.includes(s.id) ? 'blue' : 'ghost'} onClick={() => toggle(s.id)}>{p.pron.includes(s.id) ? 'Studied ✓' : 'Mark as studied'}</Btn></div>
        <p className="mt-2 max-w-prose">{s.intro}</p>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm">{s.points.map((x) => <li key={x}>{x}</li>)}</ul>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">{s.words.map(([w, note]) => (
          <div key={w} className="flex items-center justify-between rounded-md bg-slate-50 p-2 text-sm"><span><b className="text-navy">{w}</b><br /><span className="text-xs text-slate-500">{note}</span></span>
            <span className="flex gap-1"><Btn v="ghost" onClick={() => speak(w, 'en-GB')}>🇬🇧</Btn><Btn v="ghost" onClick={() => speak(w, 'en-US')}>🇺🇸</Btn></span></div>))}</div>
        <div className="mt-4 rounded-md border-2 border-dashed border-navy/40 p-3 text-sm text-slate-600">🔊 <b>Audio placeholder</b> — add your own recording at <code>public{s.audio}</code>, then replace this box with an <code>&lt;audio controls src="{s.audio}" /&gt;</code> tag. (The 🇬🇧 / 🇺🇸 buttons use your browser's built-in voices.)</div>
        <a className="mt-3 inline-block text-sm font-semibold text-flag underline" target="_blank" rel="noreferrer" href={`https://www.youtube.com/results?search_query=${encodeURIComponent(s.video)}`}>▶ Find videos on YouTube: {s.video}</a>
      </Card>))}</div></div>);
}

// ---------------- Culture ----------------
export function Culture({ p, set }: P) {
  const [id, setId] = useState(readings[0].id);
  const [res, setRes] = useState<Record<string, boolean>>({});
  const r = readings.find((x) => x.id === id)!;
  const onRes = (k: number, ok: boolean) => {
    const next = { ...res, [`${id}${k}`]: ok }; setRes(next);
    const a = next[`${id}0`], b = next[`${id}1`];
    if (a !== undefined && b !== undefined) set((x) => ({ ...x, culture: { ...x.culture, [id]: Number(a) + Number(b) } }));
  };
  return (<div><PageTitle title="Culture" sub="Five short readings comparing British and American life." />
    <Tabs tabs={readings.map((x) => x.title)} value={r.title} onChange={(t) => setId(readings.find((x) => x.title === t)!.id)} />
    <Card className="mb-4"><h2 className="mb-2 text-2xl font-bold">{r.emoji} {r.title}</h2>
      <p className="max-w-prose font-serif text-lg leading-relaxed">{r.text}</p>
      {p.culture[id] !== undefined && <p className="mt-3 text-sm text-green-700">Last score: {p.culture[id]}/2</p>}</Card>
    <div className="space-y-3">{r.qs.map((q, k) => <QuestionCard key={id + k} q={q} n={k + 1} onResult={(ok) => onRes(k, ok)} />)}</div></div>);
}

// ---------------- Practice ----------------
export function Practice({ p, set }: P) {
  const n = Object.keys(p.practice).length;
  return (<div><PageTitle title="Practice" sub={`20 activities with instant feedback. Completed: ${n}/${practice.length}`} />
    <div className="space-y-3">{practice.map((q, i) => (
      <QuestionCard key={i} q={q} n={i + 1} done={p.practice[i]} onResult={(ok) => ok && set((x) => ({ ...x, practice: { ...x.practice, [i]: true } }))} />))}</div></div>);
}

// ---------------- Final assessment ----------------
export function Final({ p, set }: P) {
  const [started, setStarted] = useState(false); const [run, setRun] = useState(0);
  return (<div><PageTitle title="Final Assessment" sub="30 multiple-choice questions on vocabulary, spelling, pronunciation and culture." />
    {!started ? (<Card className="text-center">
      {p.final && <p className="mb-3 text-lg">Last result: <b className="text-navy">{p.final.score}/{p.final.total}</b> on {p.final.date}</p>}
      <p className="mb-4 text-slate-600">You will see your score and a review of mistakes at the end.</p><Btn v="red" onClick={() => setStarted(true)}>{p.final ? 'Retake the test' : 'Start the test'}</Btn></Card>)
      : <Test key={run} questions={finalTest} onRestart={() => setRun(run + 1)} onFinish={(s) => set((x) => ({ ...x, final: { score: s, total: finalTest.length, date: new Date().toLocaleDateString('en-GB') } }))} />}</div>);
}
