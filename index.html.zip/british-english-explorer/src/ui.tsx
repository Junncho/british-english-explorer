import { useEffect, useState, type ButtonHTMLAttributes, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import type { Q } from './data';

export function useLocal<T extends object>(key: string, init: T): [T, Dispatch<SetStateAction<T>>] {
  const [v, setV] = useState<T>(() => {
    try { const s = localStorage.getItem(key); return s ? { ...init, ...JSON.parse(s) } : init; } catch { return init; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* storage unavailable */ } }, [key, v]);
  return [v, setV];
}

export const speak = (text: string, lang: 'en-GB' | 'en-US') => {
  if (!('speechSynthesis' in window)) { alert('Speech is not supported in this browser.'); return; }
  const u = new SpeechSynthesisUtterance(text); u.lang = lang; u.rate = 0.85;
  window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
};

export const Card = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-lg border border-slate-300 bg-white p-5 shadow-sm ${className}`}>{children}</div>
);

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { v?: 'red' | 'blue' | 'ghost' };
const variants = { red: 'bg-flag text-white hover:bg-red-800', blue: 'bg-navy text-white hover:bg-blue-900', ghost: 'border border-navy text-navy hover:bg-blue-50' };
export const Btn = ({ v = 'blue', className = '', ...rest }: BtnProps) => (
  <button {...rest} className={`rounded-md px-4 py-2 text-sm font-semibold transition disabled:opacity-40 ${variants[v]} ${className}`} />
);

export const Bar = ({ pct }: { pct: number }) => (
  <div className="h-2 w-full rounded-full bg-slate-200"><div className="h-2 rounded-full bg-flag transition-all" style={{ width: `${Math.round(Math.min(1, pct) * 100)}%` }} /></div>
);

export const Tabs = ({ tabs, value, onChange }: { tabs: string[]; value: string; onChange: (t: string) => void }) => (
  <div className="mb-5 flex flex-wrap gap-2">
    {tabs.map((t) => (
      <button key={t} onClick={() => onChange(t)} className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${t === value ? 'border-navy bg-navy text-white' : 'border-navy/30 bg-white text-navy hover:bg-blue-50'}`}>{t}</button>
    ))}
  </div>
);

export const PageTitle = ({ title, sub }: { title: string; sub: string }) => (
  <div className="mb-6 border-l-8 border-flag pl-4"><h1 className="text-3xl font-bold">{title}</h1><p className="text-slate-600">{sub}</p></div>
);

// One question with instant feedback. Multiple choice if q.options exists, otherwise typed answer.
export function QuestionCard({ q, n, onResult, done }: { q: Q; n: number; onResult?: (ok: boolean) => void; done?: boolean }) {
  const [pick, setPick] = useState('');
  const [checked, setChecked] = useState(false);
  const submit = (value: string) => { setPick(value); setChecked(true); onResult?.(value.trim().toLowerCase() === q.answer.toLowerCase()); };
  const ok = pick.trim().toLowerCase() === q.answer.toLowerCase();
  return (
    <Card className={checked ? (ok ? 'border-green-600' : 'border-flag') : ''}>
      <p className="mb-3 font-semibold text-navy">{n}. {q.q} {done && <span className="ml-2 rounded bg-green-100 px-2 py-0.5 text-xs text-green-800">completed</span>}</p>
      {q.options ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {q.options.map((o) => (
            <button key={o} disabled={checked} onClick={() => submit(o)}
              className={`rounded-md border px-3 py-2 text-left text-sm ${checked && o === q.answer ? 'border-green-600 bg-green-50' : checked && o === pick ? 'border-flag bg-red-50' : 'border-slate-300 hover:bg-blue-50'}`}>{o}</button>
          ))}
        </div>
      ) : (
        <div className="flex gap-2">
          <input value={pick} disabled={checked} onChange={(e) => setPick(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && pick.trim() && !checked && submit(pick)}
            placeholder="Type your answer" className="flex-1 rounded-md border border-slate-300 px-3 py-2" />
          <Btn disabled={checked || !pick.trim()} onClick={() => submit(pick)}>Check</Btn>
        </div>
      )}
      {checked && (
        <div className="mt-3 text-sm">
          <p className={ok ? 'font-semibold text-green-700' : 'font-semibold text-flag'}>{ok ? 'Correct!' : `Not quite. The answer is "${q.answer}".`}</p>
          <p className="text-slate-600">{q.explain}</p>
          {!ok && <Btn v="ghost" className="mt-2" onClick={() => { setChecked(false); setPick(''); }}>Try again</Btn>}
        </div>
      )}
    </Card>
  );
}

// Step-by-step multiple-choice test with scoring at the end (no feedback until the result screen).
export function Test({ questions, onFinish, onRestart }: { questions: Q[]; onFinish: (score: number) => void; onRestart: () => void }) {
  const [i, setI] = useState(0);
  const [ans, setAns] = useState<string[]>([]);
  const [done, setDone] = useState(false);
  const score = ans.filter((a, k) => a === questions[k].answer).length;
  if (done) {
    const pct = Math.round((score / questions.length) * 100);
    const msg = pct >= 90 ? 'Excellent. You are ready for confident British English.' : pct >= 70 ? 'Good work. Review the mistakes below to polish your British English.' : pct >= 50 ? 'A solid start. Revisit the modules and try again.' : 'Keep going. Work through the modules and practice activities, then retake.';
    return (
      <div>
        <Card className="mb-4 text-center">
          <p className="text-5xl font-bold text-navy">{score} / {questions.length}</p>
          <p className="mt-1 text-xl text-flag">{pct}%</p><p className="mt-2 text-slate-600">{msg}</p>
          <Btn className="mt-4" onClick={onRestart}>Try again</Btn>
        </Card>
        <h3 className="mb-2 text-lg font-bold">Review your mistakes</h3>
        <div className="space-y-2">
          {questions.map((q, k) => ans[k] !== q.answer && (
            <Card key={k}><p className="font-semibold">{k + 1}. {q.q}</p><p className="text-sm text-flag">Your answer: {ans[k]}</p><p className="text-sm text-green-700">Correct: {q.answer}</p><p className="text-sm text-slate-600">{q.explain}</p></Card>
          ))}
          {score === questions.length && <p className="text-green-700">No mistakes. Perfect score!</p>}
        </div>
      </div>
    );
  }
  const q = questions[i];
  const next = () => { if (i + 1 < questions.length) setI(i + 1); else { setDone(true); onFinish(score); } };
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between text-sm text-slate-600"><span>Question {i + 1} of {questions.length}</span><span className="w-40"><Bar pct={i / questions.length} /></span></div>
      <p className="mb-4 text-lg font-semibold text-navy">{q.q}</p>
      <div className="grid gap-2">
        {q.options!.map((o) => (
          <button key={o} onClick={() => setAns((a) => { const n = [...a]; n[i] = o; return n; })}
            className={`rounded-md border px-4 py-2 text-left ${ans[i] === o ? 'border-navy bg-blue-50 font-semibold' : 'border-slate-300 hover:bg-blue-50'}`}>{o}</button>
        ))}
      </div>
      <div className="mt-4 flex justify-between">
        <Btn v="ghost" disabled={i === 0} onClick={() => setI(i - 1)}>Back</Btn>
        <Btn v="red" disabled={!ans[i]} onClick={next}>{i + 1 === questions.length ? 'Finish and score' : 'Next'}</Btn>
      </div>
    </Card>
  );
}
