import { useState } from 'react';
import { emptyProgress, practice, pron, readings, spelling, vocab, type Progress } from './data';
import { Bar, Btn, Card, useLocal } from './ui';
import { Culture, Final, Practice, Pronunciation, Spelling, Vocabulary } from './modules';

const Flag = ({ className = 'h-8' }: { className?: string }) => (
  <svg viewBox="0 0 60 30" className={className} aria-label="Union Jack">
    <clipPath id="s"><path d="M0,0 v30 h60 v-30 z" /></clipPath><clipPath id="t"><path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z" /></clipPath>
    <g clipPath="url(#s)"><path d="M0,0 v30 h60 v-30 z" fill="#012169" /><path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6" />
      <path d="M0,0 L60,30 M60,0 L0,30" clipPath="url(#t)" stroke="#C8102E" strokeWidth="4" /><path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10" /><path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6" /></g>
  </svg>
);

const modules = [
  { id: 'vocab', label: 'Vocabulary', icon: '🕰️', place: 'Big Ben', desc: 'Flashcards and quizzes on 50 UK/US word pairs.' },
  { id: 'spelling', label: 'Spelling', icon: '🗿', place: 'Stonehenge', desc: 'Ancient rules, modern practice: -our, -re, -ise and more.' },
  { id: 'pron', label: 'Pronunciation', icon: '🎙️', place: 'The Tube', desc: 'T and R sounds, intonation and rhythm, with audio and video.' },
  { id: 'culture', label: 'Culture', icon: '👑', place: 'Buckingham Palace', desc: 'Five short readings with comprehension questions.' },
  { id: 'practice', label: 'Practice', icon: '🎯', place: 'Practice', desc: '20 activities with automatic feedback.' },
  { id: 'final', label: 'Final Assessment', icon: '🇬🇧', place: 'Union Jack', desc: 'A 30-question test with automatic scoring.' },
];

export default function App() {
  const [p, set] = useLocal<Progress>('british-english-explorer-v1', emptyProgress);
  const [page, setPage] = useState('home');
  const pct: Record<string, number> = {
    vocab: p.known.length / vocab.length, spelling: p.spelled.length / spelling.length, pron: p.pron.length / pron.length,
    culture: Object.keys(p.culture).length / readings.length, practice: Object.keys(p.practice).length / practice.length, final: p.final ? 1 : 0,
  };
  const overall = Object.values(pct).reduce((a, b) => a + b, 0) / modules.length;
  const props = { p, set };

  return (
    <div className="min-h-screen">
      <header className="bg-navy text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <button onClick={() => setPage('home')} className="flex items-center gap-3 text-left"><Flag className="h-9 rounded-sm border border-white/60" /><span className="font-serif text-xl font-bold">British English Explorer</span></button>
          <nav className="ml-auto flex flex-wrap gap-1 text-sm">
            {[{ id: 'home', label: 'Home' }, ...modules].map((m) => (
              <button key={m.id} onClick={() => setPage(m.id)} className={`rounded px-3 py-1.5 font-semibold ${page === m.id ? 'bg-white text-navy' : 'hover:bg-white/15'}`}>{m.label}</button>))}
          </nav>
        </div>
        <div className="flex h-1.5"><div className="flex-1 bg-flag" /><div className="flex-1 bg-white" /><div className="flex-1 bg-flag" /></div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {page === 'home' && (
          <div>
            <section className="relative overflow-hidden rounded-lg bg-navy p-8 text-white md:p-12">
              <Flag className="absolute -right-10 -top-6 hidden h-72 opacity-15 md:block" />
              <h1 className="max-w-xl text-4xl font-bold !text-white md:text-5xl">Sound, spell and think British.</h1>
              <p className="mt-4 max-w-xl text-lg text-blue-100">A practical course for B1 to C1 learners who want to understand and use British English with confidence.</p>
              <div className="mt-6 flex flex-wrap gap-3 text-sm"><Btn v="red" onClick={() => setPage('vocab')}>Start with vocabulary</Btn><Btn className="!bg-white !text-navy hover:!bg-blue-50" onClick={() => setPage('final')}>Take the final test</Btn></div>
            </section>

            <div className="mt-6 grid gap-6 md:grid-cols-3">
              <Card className="md:col-span-2">
                <h2 className="mb-2 text-2xl font-bold">What is British English?</h2>
                <p className="max-w-prose">British English is the variety of English used in the United Kingdom. It differs from American English in vocabulary (<i>lift</i> vs <i>elevator</i>), spelling (<i>colour</i> vs <i>color</i>), pronunciation (the silent R in <i>car</i>), some grammar (<i>the team are</i>, <i>have you got…?</i>) and culture. Many accents exist, from Received Pronunciation to Scouse, Geordie and Scottish English, and all of them are valid.</p>
                <p className="mt-3 max-w-prose text-sm text-slate-600">Neither variety is "better". Learn the British forms, notice the differences, and stay consistent in your own writing and speech.</p>
              </Card>
              <Card>
                <h2 className="mb-2 text-xl font-bold">Your progress</h2>
                <p className="text-5xl font-bold text-flag">{Math.round(overall * 100)}%</p><div className="my-3"><Bar pct={overall} /></div>
                <p className="text-sm text-slate-600">Saved in this browser. {p.final && <>Final test: <b>{p.final.score}/{p.final.total}</b>.</>}</p>
                <button className="mt-3 text-xs text-slate-500 underline" onClick={() => confirm('Reset all progress?') && set(emptyProgress)}>Reset progress</button>
              </Card>
            </div>

            <h2 className="mb-3 mt-8 text-2xl font-bold">Modules</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {modules.map((m) => (
                <button key={m.id} onClick={() => setPage(m.id)} className="rounded-lg border-t-4 border-flag bg-white p-5 text-left shadow-sm hover:shadow-md">
                  <div className="text-3xl">{m.icon}</div><h3 className="mt-2 text-xl font-bold">{m.label}</h3><p className="text-xs text-slate-500">{m.place}</p>
                  <p className="my-2 text-sm">{m.desc}</p><Bar pct={pct[m.id]} /><p className="mt-1 text-xs text-slate-500">{Math.round(pct[m.id] * 100)}% complete</p>
                </button>))}
            </div>
          </div>
        )}
        {page === 'vocab' && <Vocabulary {...props} />}
        {page === 'spelling' && <Spelling {...props} />}
        {page === 'pron' && <Pronunciation {...props} />}
        {page === 'culture' && <Culture {...props} />}
        {page === 'practice' && <Practice {...props} />}
        {page === 'final' && <Final {...props} />}
      </main>
      <footer className="py-6 text-center text-xs text-slate-500">British English Explorer · prototype · progress is stored in your browser only</footer>
    </div>
  );
}
