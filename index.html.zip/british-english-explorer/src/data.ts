export type Q = { q: string; options?: string[]; answer: string; explain: string };
export type Progress = {
  known: string[]; vocabBest: number; spelled: string[]; pron: string[];
  culture: Record<string, number>; practice: Record<string, boolean>;
  final: { score: number; total: number; date: string } | null;
};
export const emptyProgress: Progress = { known: [], vocabBest: 0, spelled: [], pron: [], culture: {}, practice: {}, final: null };

// ---------- Vocabulary: British | American (50 pairs) ----------
export const vocab: [string, string][] = ('lift|elevator;flat|apartment;lorry|truck;petrol|gas;boot|trunk;bonnet|hood;pavement|sidewalk;queue|line;biscuit|cookie;crisps|chips;chips|fries;sweets|candy;jumper|sweater;trousers|pants;trainers|sneakers;rubbish|trash;bin|trash can;torch|flashlight;holiday|vacation;mobile phone|cell phone;nappy|diaper;pram|stroller;football|soccer;cinema|movie theater;film|movie;post|mail;postcode|zip code;motorway|highway;roundabout|traffic circle;car park|parking lot;underground|subway;tap|faucet;aubergine|eggplant;courgette|zucchini;coriander|cilantro;rocket|arugula;chemist|pharmacy;autumn|fall;maths|math;timetable|schedule;rubber|eraser;waistcoat|vest;braces|suspenders;wardrobe|closet;estate agent|realtor;solicitor|lawyer;take-away|take-out;jam|jelly;plaster|band-aid;dummy|pacifier')
  .split(';').map((s) => s.split('|') as [string, string]);

// Pairs whose words clash across the two varieties (e.g. UK "chips" vs US "chips") are kept out of quizzes.
export const pool = vocab.filter(([u, a]) => !vocab.some(([u2, a2]) => u2 === a || a2 === u));

export function pairQ(i: number, dir: 'us2uk' | 'uk2us'): Q {
  const [uk, us] = pool[i % pool.length];
  const d = [11, 23, 37].map((o) => pool[(i + o) % pool.length]);
  const correct = dir === 'us2uk' ? uk : us;
  const opts = d.map((p) => (dir === 'us2uk' ? p[0] : p[1]));
  opts.splice(i % 4, 0, correct);
  return {
    q: dir === 'us2uk' ? `Which word would a British speaker use for "${us}"?` : `What would an American say for the British word "${uk}"?`,
    options: opts, answer: correct, explain: `British "${uk}" = American "${us}".`,
  };
}

// ---------- Spelling: British | American | rule ----------
const ER = 're / er', OR = 'our / or', IZ = 'ise / ize', SE = 'ce / se', LL = 'single / double L', OG = 'ogue / og', OT = 'Other';
export const spelling: [string, string, string][] = [
  ['colour', 'color', OR], ['favourite', 'favorite', OR], ['neighbour', 'neighbor', OR], ['behaviour', 'behavior', OR], ['honour', 'honor', OR],
  ['centre', 'center', ER], ['theatre', 'theater', ER], ['metre', 'meter', ER], ['fibre', 'fiber', ER],
  ['organise', 'organize', IZ], ['realise', 'realize', IZ], ['apologise', 'apologize', IZ], ['recognise', 'recognize', IZ],
  ['defence', 'defense', SE], ['licence', 'license', SE], ['offence', 'offense', SE],
  ['travelling', 'traveling', LL], ['cancelled', 'canceled', LL], ['jewellery', 'jewelry', LL],
  ['catalogue', 'catalog', OG], ['dialogue', 'dialog', OG],
  ['grey', 'gray', OT], ['tyre', 'tire', OT], ['programme', 'program', OT], ['cheque', 'check', OT], ['aluminium', 'aluminum', OT],
];
export const spellRules = Array.from(new Set(spelling.map((s) => s[2])));
export function spellQ(i: number, k: number): Q {
  const [uk, us, rule] = spelling[i];
  return { q: 'Which spelling is standard in British English?', options: k % 2 ? [us, uk] : [uk, us], answer: uk, explain: `${rule}: British "${uk}", American "${us}".` };
}

// ---------- Pronunciation ----------
export const pron = [
  { id: 't', title: 'The T sound', audio: '/audio/t-sound.mp3',
    intro: 'Between vowels, American English often turns /t/ into a quick, soft "flap" that sounds like a D. British English keeps a clearer /t/, and in casual speech may replace it with a glottal stop (a tiny catch in the throat).',
    points: ['US: "water" sounds like "wah-der" (flap T).', 'UK: "water" has a crisp T, or "wo-\'er" in casual London speech (glottal stop).', 'Glottal stops are common before consonants and at the ends of words: "football", "got".', 'Both varieties are correct. Pick one and stay consistent.'],
    words: [['water', 'flap vs clear T'], ['butter', 'flap vs clear T'], ['better', 'flap vs clear T'], ['bottle', 'glottal stop is common in UK'], ['city', 'flap vs clear T']],
    video: 'BBC Learning English British vs American T sound' },
  { id: 'r', title: 'The R sound', audio: '/audio/r-sound.mp3',
    intro: 'Standard British English is non-rhotic: R is only pronounced before a vowel. American English is rhotic: R is pronounced almost everywhere.',
    points: ['"car", "park", "mother": the R is silent in the UK, pronounced in the US.', 'Linking R: "far away" and "here it is" do have an R, because a vowel follows.', 'UK vowels fill the gap: "here" ends in a glide (/hɪə/), "car" has a long /ɑː/.', 'Scottish, Irish and some West Country accents in Britain are rhotic.'],
    words: [['car', 'UK: no R sound'], ['park', 'UK: no R sound'], ['mother', 'UK: ends in a schwa'], ['far away', 'linking R in both'], ['here', 'UK: glide ending']],
    video: 'BBC Learning English rhotic non-rhotic accents' },
  { id: 'i', title: 'Intonation', audio: '/audio/intonation.mp3',
    intro: 'British intonation uses a wide pitch range and many fall-rise tunes that sound polite or tentative. American speech often sounds flatter, with more even pitch.',
    points: ['Statements and wh-questions usually fall: "Where do you live?" ↘', 'Yes/no questions usually rise: "Are you coming?" ↗', 'Fall-rise shows politeness or doubt: "It\'s quite good…" ↘↗ (often means "not great").', 'Lists rise on each item and fall on the last: "tea ↗, coffee ↗ or milk ↘".'],
    words: [['Where do you live?', 'falling'], ['Are you coming?', 'rising'], ['It\'s quite good.', 'fall-rise = polite doubt'], ['Lovely to meet you!', 'high start, wide range']],
    video: 'BBC Learning English intonation British English' },
  { id: 'h', title: 'Rhythm and stress', audio: '/audio/rhythm.mp3',
    intro: 'English is stress-timed: stressed syllables come at roughly regular intervals, and unstressed syllables are squeezed in between and shortened. British speech often reduces unstressed vowels to a schwa more strongly.',
    points: ['Content words (nouns, verbs, adjectives) get stress; function words are weak.', '"I want to go to the SHOP" → "I wanna GO to the SHOP" with weak "to" and "the".', 'Different stress: UK "adVERtisement", US "ADvertisement"; UK "garage" (GAR-ij) vs US "guh-RAHJ".', 'Practise by tapping the beat on stressed words only.'],
    words: [['I want to go to the shop.', 'stress: want, go, shop'], ['advertisement', 'UK: ad-VER-tis-ment'], ['garage', 'UK: GA-rij'], ['laboratory', 'UK: la-BOR-a-try']],
    video: 'BBC Learning English sentence stress rhythm' },
];

// ---------- Culture readings ----------
export type Reading = { id: string; title: string; emoji: string; text: string; qs: Q[] };
export const readings: Reading[] = [
  { id: 'queue', title: 'The Great British Queue', emoji: '🚏',
    text: 'In Britain, people do not stand in line; they queue. Queueing is almost a national habit, from bus stops to supermarkets. Pushing in, or "jumping the queue", is considered very rude, and people will often show their annoyance with a quiet cough or a pointed "Excuse me." Americans also wait in line patiently, but the British word and the strong social rule behind it are part of everyday British identity.',
    qs: [{ q: 'What do British people call standing in a line?', options: ['A queue', 'A row', 'A rank', 'A string'], answer: 'A queue', explain: 'Queue is the British word; Americans say "line".' },
         { q: 'What does "jumping the queue" mean?', options: ['Leaving a queue early', 'Pushing in front of others', 'Standing very close to someone', 'Organising a queue'], answer: 'Pushing in front of others', explain: 'It is considered very rude in Britain.' }] },
  { id: 'tea', title: 'Tea Time', emoji: '🫖',
    text: 'Tea is Britain\'s traditional drink. Most people have it hot, strong and with milk, and they call it "a cuppa". Afternoon tea, with small sandwiches, scones, jam and cream, is more of a special treat than a daily habit. In the United States, coffee is generally the everyday hot drink, although iced tea is popular, especially in the South.',
    qs: [{ q: 'How do many British people take their tea?', options: ['With milk', 'With lemon only', 'Iced', 'Without water'], answer: 'With milk', explain: 'Milk in tea is very common in Britain.' },
         { q: 'According to the text, afternoon tea is…', options: ['a daily habit for everyone', 'a special treat', 'only for children', 'a type of coffee'], answer: 'a special treat', explain: 'Most people do not have a full afternoon tea every day.' }] },
  { id: 'school', title: 'School Days', emoji: '🎒',
    text: 'School vocabulary can be confusing. In Britain, children attend primary school and then secondary school, while Americans say elementary school and high school. A British "public school" is actually a private, fee-paying school, whereas in the US a public school is free and run by the state. Most British schools, including state schools, have uniforms, which are much less common in the US.',
    qs: [{ q: 'What does "public school" often mean in Britain?', options: ['A free state school', 'A private, fee-paying school', 'A university', 'A nursery'], answer: 'A private, fee-paying school', explain: 'This is a classic "false friend" between UK and US usage.' },
         { q: 'Which is more common in British schools than in US schools?', options: ['Uniforms', 'Yellow buses', 'Semesters', 'Lockers'], answer: 'Uniforms', explain: 'The text says uniforms are much less common in the US.' }] },
  { id: 'sport', title: 'The Beautiful Game', emoji: '⚽',
    text: 'When a British person says "football", they mean what Americans call soccer. It is the most popular sport in Britain, with passionate local rivalries and fans who sing at matches. Rugby and cricket are also important; cricket is traditionally played in summer and can last for five days in its longest form. In the US, American football, baseball and basketball are the big three.',
    qs: [{ q: 'What do British people mean by "football"?', options: ['American football', 'Soccer', 'Rugby', 'Cricket'], answer: 'Soccer', explain: 'Football in Britain = soccer in the US.' },
         { q: 'Which sport is traditionally played in summer in Britain?', options: ['Cricket', 'Basketball', 'Ice hockey', 'Baseball'], answer: 'Cricket', explain: 'The text links cricket with summer.' }] },
  { id: 'pub', title: 'Eating and Drinking Out', emoji: '🍺',
    text: 'The pub is a social centre in many British towns. In a traditional pub you usually order and pay at the bar rather than waiting for table service, and people often take turns buying a "round" of drinks for the group. Tipping is also different: in restaurants a service charge of about 10 to 12.5 per cent is often added to the bill, so extra tips are smaller than the 15 to 20 per cent usual in the US.',
    qs: [{ q: 'Where do you usually order drinks in a traditional pub?', options: ['At the bar', 'At the table', 'By telephone', 'At the door'], answer: 'At the bar', explain: 'Ordering at the bar is the normal pub custom.' },
         { q: 'How does tipping in Britain compare with the US?', options: ['It is usually smaller', 'It is always larger', 'It is illegal', 'It is identical'], answer: 'It is usually smaller', explain: 'A service charge is often included and the usual amount is lower.' }] },
];

// ---------- Practice (20) and Final test (30) ----------
export const practice: Q[] = [
  ...Array.from({ length: 12 }, (_, i) => pairQ(i * 3, i < 6 ? 'us2uk' : 'uk2us')),
  ...[0, 6, 12, 18].map((s, k) => spellQ(s, k)),
  { q: 'Fill the gap: "Take the ___ to the third floor." (US: elevator)', answer: 'lift', explain: 'British English: lift.' },
  { q: 'Fill the gap: "We need to stop for ___ before the motorway." (US: gas)', answer: 'petrol', explain: 'British English: petrol.' },
  { q: 'Fill the gap: "We are going on ___ to Cornwall." (US: vacation)', answer: 'holiday', explain: 'British English: holiday.' },
  { q: 'Fill the gap: "My ___ colour is blue." (US spelling: favorite)', answer: 'favourite', explain: 'British spelling keeps the U: favourite.' },
];
export const finalTest: Q[] = [
  ...Array.from({ length: 15 }, (_, i) => pairQ(i * 3 + 1, i % 2 ? 'uk2us' : 'us2uk')),
  ...[1, 4, 8, 11, 14, 17, 20, 23].map((s, k) => spellQ(s, k)),
  { q: 'In standard British English, the R in "car" is…', options: ['not pronounced', 'strongly rolled', 'always pronounced', 'replaced with L'], answer: 'not pronounced', explain: 'British English is non-rhotic: R is silent unless a vowel follows.' },
  { q: 'Which pronunciation of "water" is typical of American English?', options: ['"wah-der" with a flap T', '"wo-ter" with a very clear T', '"wo-\'er" with a glottal stop', '"wo-ruh" with no T'], answer: '"wah-der" with a flap T', explain: 'American speakers often flap the T between vowels.' },
  { q: 'Which intonation is typical for "Where do you live?"', options: ['Falling', 'Rising', 'Flat', 'Rising, then falling, then rising'], answer: 'Falling', explain: 'Wh-questions usually fall.' },
  { q: 'What does "stress-timed" mean?', options: ['Stressed syllables come at regular intervals', 'Every syllable is the same length', 'Only the first word is stressed', 'Speakers pause after each word'], answer: 'Stressed syllables come at regular intervals', explain: 'Unstressed syllables are shortened to fit the rhythm.' },
  { q: 'A British person says their child goes to a "public school". The school is most likely…', options: ['private and fee-paying', 'free and state-run', 'a university', 'a language school'], answer: 'private and fee-paying', explain: 'Public school in Britain usually means a private school.' },
  { q: 'Where do you usually order drinks in a traditional British pub?', options: ['At the bar', 'From a waiter at the table', 'By phone', 'Outside'], answer: 'At the bar', explain: 'Ordering at the bar is the custom.' },
  { q: '"Jumping the queue" means…', options: ['pushing in front of others', 'leaving a line', 'organising a line', 'waiting patiently'], answer: 'pushing in front of others', explain: 'It is considered rude in Britain.' },
];
