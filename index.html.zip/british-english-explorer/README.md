# British English Explorer (prototype)
React + TypeScript + Tailwind CSS (Vite). No backend; progress saved in localStorage.

    npm install
    npm run dev      # open the printed local URL
    npm run build    # type-check + production build
