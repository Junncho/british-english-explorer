/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { navy: '#012169', flag: '#C8102E', stone: '#EDEAE3' }, fontFamily: { serif: ['Georgia', 'Cambria', 'Times New Roman', 'serif'] } } },
  plugins: [],
};
